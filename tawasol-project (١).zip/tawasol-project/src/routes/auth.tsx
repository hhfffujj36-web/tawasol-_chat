import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sparkles, Phone, Lock, User } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({ component: AuthPage });

// Libyan phone: 09XXXXXXXX -> convert to fake email so we can use email/password
function phoneToEmail(phone: string) {
  return `${phone}@tawasol.app`;
}

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/" });
    });
  }, [navigate]);

  const validPhone = /^09\d{8}$/.test(phone);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validPhone) return toast.error("رقم الهاتف غير صالح (09XXXXXXXX)");
    if (password.length < 6) return toast.error("كلمة المرور 6 أحرف على الأقل");
    if (mode === "signup" && name.trim().length < 2) return toast.error("اكتب اسمك");
    setBusy(true);
    try {
      const email = phoneToEmail(phone);
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { name: name.trim(), phone } },
        });
        if (error) throw error;
        // Ensure profile row (trigger handles it, but update name+phone in case)
        if (data.user) {
          await supabase.from("profiles").upsert({
            id: data.user.id,
            phone,
            name: name.trim(),
          });
        }
        toast.success("تم إنشاء حسابك");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("مرحبا بعودتك");
      }
      navigate({ to: "/" });
    } catch (err: any) {
      toast.error(err?.message ?? "فشل");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-gradient-brand">
      <div className="pointer-events-none absolute -top-40 -right-32 h-96 w-96 rounded-full bg-white/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-32 h-96 w-96 rounded-full bg-fuchsia-400/30 blur-3xl" />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-10">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md ring-1 ring-white/40">
            <Sparkles className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-3xl font-black text-white">تواصل</h1>
          <p className="mt-1 text-sm text-white/80">
            {mode === "login" ? "سجل دخولك للمتابعة" : "أنشئ حسابك بسرعة"}
          </p>
        </div>

        <div className="rounded-3xl bg-white/95 p-6 shadow-2xl">
          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <label className="block">
                <span className="mb-2 flex items-center gap-1 text-sm font-semibold text-foreground/80">
                  <User className="h-4 w-4" /> الاسم
                </span>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="اسمك"
                  className="w-full rounded-2xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-4 focus:ring-primary/15"
                />
              </label>
            )}
            <label className="block">
              <span className="mb-2 flex items-center gap-1 text-sm font-semibold text-foreground/80">
                <Phone className="h-4 w-4" /> رقم الهاتف
              </span>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                placeholder="09XXXXXXXX"
                dir="ltr"
                className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-lg outline-none focus:border-primary focus:ring-4 focus:ring-primary/15"
              />
            </label>
            <label className="block">
              <span className="mb-2 flex items-center gap-1 text-sm font-semibold text-foreground/80">
                <Lock className="h-4 w-4" /> كلمة المرور
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="6 أحرف على الأقل"
                className="w-full rounded-2xl border border-border bg-background px-4 py-3 outline-none focus:border-primary focus:ring-4 focus:ring-primary/15"
              />
            </label>

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-2xl bg-gradient-brand py-4 text-lg font-bold text-white shadow-lg shadow-indigo-700/30 active:scale-[0.98] disabled:opacity-70"
            >
              {busy ? "..." : mode === "login" ? "دخول" : "إنشاء حساب"}
            </button>

            <button
              type="button"
              onClick={() => setMode(mode === "login" ? "signup" : "login")}
              className="w-full text-center text-sm text-primary hover:underline"
            >
              {mode === "login" ? "ليس لديك حساب؟ سجّل الآن" : "لديك حساب؟ سجّل الدخول"}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
