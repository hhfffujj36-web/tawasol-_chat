import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useNavigate,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { registerSW } from "../lib/register-sw";
import { supabase } from "@/integrations/supabase/client";
import { ensureGuestSession } from "@/lib/guest-auth";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold">الصفحة غير موجودة</h2>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
            الرجوع للرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">فيه مشكلة</h1>
        <p className="mt-2 text-sm text-muted-foreground">صار خطأ. جرب مرة أخرى.</p>
        <div className="mt-6">
          <button onClick={() => { router.invalidate(); reset(); }} className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">
            إعادة المحاولة
          </button>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "تواصل — تواصل مع اللي حولك" },
      { name: "description", content: "تطبيق تواصل: اكتشف الأشخاص القريبين وابدأ محادثة لحظية." },
      { property: "og:title", content: "تواصل" },
      { property: "og:description", content: "اكتشف الأشخاص القريبين وابدأ محادثة." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#8B5CF6" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/icon-192.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/icon-192.png" },
      { rel: "manifest", href: "/manifest.json" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

const PUBLIC_ROUTES = new Set(["/auth"]);

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => { registerSW(); }, []);

  // Auth guard + presence
  useEffect(() => {
    let heartbeat: number | undefined;
    let userId: string | null = null;

    const setOnline = async (online: boolean) => {
      if (!userId) return;
      await supabase.from("profiles").update({
        is_online: online,
        last_seen: new Date().toISOString(),
      }).eq("id", userId);
    };

    const applyAuth = async (session: any) => {
      userId = session?.user?.id ?? null;
      if (!session && !PUBLIC_ROUTES.has(pathname)) {
        // Guest bypass: auto-provision a per-device guest session instead of redirecting to /auth.
        try {
          await ensureGuestSession();
        } catch (e) {
          console.error("guest session bootstrap failed", e);
        }
        return; // onAuthStateChange will fire again with the new session
      }
      if (session) {
        setOnline(true);
        if (heartbeat) window.clearInterval(heartbeat);
        heartbeat = window.setInterval(() => setOnline(true), 30_000);
      } else {
        if (heartbeat) window.clearInterval(heartbeat);
      }
    };

    supabase.auth.getSession().then(({ data }) => applyAuth(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => applyAuth(s));

    const onHide = () => setOnline(document.visibilityState === "visible");
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("beforeunload", () => setOnline(false));

    return () => {
      sub.subscription.unsubscribe();
      if (heartbeat) window.clearInterval(heartbeat);
      document.removeEventListener("visibilitychange", onHide);
    };
  }, [navigate, pathname]);

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
      <Toaster position="top-center" richColors dir="rtl" />
    </QueryClientProvider>
  );
}
