import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { getMyStory, type Story } from "../lib/story";
import { getProfile } from "../lib/profile";
import { nearbyUsers } from "../lib/mock-users";

export const Route = createFileRoute("/story/$id")({
  component: StoryView,
});

const IMG_DURATION = 5000;

function StoryView() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [story, setStory] = useState<Story | null>(null);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const isMine = id === "me";
  const user = nearbyUsers.find((u) => u.id === id);
  const profile = typeof window !== "undefined" ? getProfile() : null;
  const name = isMine ? profile?.name ?? "أنا" : user?.name ?? "مستخدم";

  useEffect(() => {
    if (isMine) {
      setStory(getMyStory());
    } else {
      // Simulated friend story: reuse image from mock (or empty)
      setStory({
        type: "image",
        data:
          "data:image/svg+xml;utf8," +
          encodeURIComponent(
            `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 700'><defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop offset='0' stop-color='%238b5cf6'/><stop offset='1' stop-color='%236366f1'/></linearGradient></defs><rect width='400' height='700' fill='url(%23g)'/><text x='50%25' y='50%25' fill='white' font-size='42' font-family='sans-serif' text-anchor='middle' dominant-baseline='middle'>${name}</text></svg>`,
          ),
        timestamp: Date.now(),
      });
    }
  }, [id, isMine, name]);

  useEffect(() => {
    if (!story) return;
    if (story.type === "image") {
      const start = Date.now();
      const iv = setInterval(() => {
        const p = Math.min(100, ((Date.now() - start) / IMG_DURATION) * 100);
        setProgress(p);
        if (p >= 100) {
          clearInterval(iv);
          navigate({ to: "/" });
        }
      }, 60);
      return () => clearInterval(iv);
    }
  }, [story, navigate]);

  const onVideoTime = () => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    setProgress((v.currentTime / v.duration) * 100);
  };

  if (!story) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-black text-white">
        <p>لا يوجد ستوري</p>
      </main>
    );
  }

  const timeAgo = (() => {
    const mins = Math.floor((Date.now() - story.timestamp) / 60000);
    if (mins < 1) return "الآن";
    if (mins < 60) return `${mins} د`;
    return `${Math.floor(mins / 60)} س`;
  })();

  return (
    <main
      className="fixed inset-0 z-50 flex flex-col bg-black text-white"
      onClick={(e) => {
        const w = window.innerWidth;
        if (e.clientX < w / 3) return; // back — no prev
        if (e.clientX > (w * 2) / 3) navigate({ to: "/" });
      }}
    >
      {/* progress */}
      <div className="px-3 pt-3">
        <div className="h-1 w-full overflow-hidden rounded-full bg-white/20">
          <div
            className="h-full transition-[width]"
            style={{ width: `${progress}%`, backgroundColor: "#8b5cf6" }}
          />
        </div>
      </div>

      {/* header */}
      <div className="flex items-center gap-3 px-4 py-3">
        <div
          className="flex h-9 w-9 items-center justify-center rounded-full text-sm font-black"
          style={{ backgroundColor: "#8b5cf6" }}
        >
          {name.charAt(0)}
        </div>
        <div className="flex-1">
          <p className="text-sm font-bold">{name}</p>
          <p className="text-xs text-white/70">{timeAgo}</p>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate({ to: "/" });
          }}
          className="rounded-full p-1.5 hover:bg-white/10"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* content */}
      <div className="flex flex-1 items-center justify-center px-2 pb-6">
        {story.type === "image" ? (
          <img src={story.data} alt="" className="max-h-full max-w-full rounded-2xl" />
        ) : (
          <video
            ref={videoRef}
            src={story.data}
            autoPlay
            playsInline
            onTimeUpdate={onVideoTime}
            onEnded={() => navigate({ to: "/" })}
            className="max-h-full max-w-full rounded-2xl"
          />
        )}
      </div>
    </main>
  );
}
