import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { ArrowRight, Image as ImageIcon, Video as VideoIcon } from "lucide-react";
import { fileToBase64 } from "../lib/chat-storage";
import { saveMyStory } from "../lib/story";

export const Route = createFileRoute("/add-story")({
  component: AddStory,
});

const MAX = 10 * 1024 * 1024;

function AddStory() {
  const navigate = useNavigate();
  const [type, setType] = useState<"image" | "video" | null>(null);
  const [data, setData] = useState<string | null>(null);
  const imgRef = useRef<HTMLInputElement>(null);
  const vidRef = useRef<HTMLInputElement>(null);

  const pick = async (
    e: React.ChangeEvent<HTMLInputElement>,
    kind: "image" | "video",
  ) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > MAX) {
      alert("الحجم أكبر من 10 ميغا");
      return;
    }
    setType(kind);
    setData(await fileToBase64(f));
  };

  const publish = () => {
    if (!type || !data) return;
    saveMyStory({ type, data, timestamp: Date.now() });
    navigate({ to: "/" });
  };

  return (
    <main className="min-h-screen bg-background">
      <header className="bg-gradient-brand px-5 py-6 text-white">
        <div className="mx-auto flex max-w-md items-center gap-3">
          <Link to="/" className="rounded-full bg-white/15 p-2 backdrop-blur-md">
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-black">إضافة ستوري</h1>
        </div>
      </header>

      <section className="mx-auto max-w-md space-y-4 px-5 py-8">
        {!data ? (
          <div className="grid grid-cols-2 gap-3">
            <input
              ref={imgRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => pick(e, "image")}
            />
            <input
              ref={vidRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => pick(e, "video")}
            />
            <button
              onClick={() => imgRef.current?.click()}
              className="flex flex-col items-center gap-2 rounded-3xl bg-card p-8 ring-1 ring-border hover:-translate-y-0.5 hover:shadow-md transition"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                <ImageIcon className="h-7 w-7" />
              </div>
              <p className="font-bold">صورة</p>
            </button>
            <button
              onClick={() => vidRef.current?.click()}
              className="flex flex-col items-center gap-2 rounded-3xl bg-card p-8 ring-1 ring-border hover:-translate-y-0.5 hover:shadow-md transition"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                <VideoIcon className="h-7 w-7" />
              </div>
              <p className="font-bold">فيديو</p>
            </button>
          </div>
        ) : (
          <>
            <div className="overflow-hidden rounded-3xl bg-black ring-1 ring-border">
              {type === "image" ? (
                <img src={data} alt="" className="max-h-[420px] w-full object-contain" />
              ) : (
                <video src={data} controls className="max-h-[420px] w-full" />
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setData(null);
                  setType(null);
                }}
                className="flex-1 rounded-2xl border border-border bg-card py-3 font-semibold"
              >
                إلغاء
              </button>
              <button
                onClick={publish}
                className="flex-1 rounded-2xl bg-gradient-brand py-3 font-bold text-white shadow-lg"
              >
                نشر
              </button>
            </div>
          </>
        )}
      </section>
    </main>
  );
}
