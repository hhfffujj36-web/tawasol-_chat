import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Send, ImageIcon, Mic, MoreVertical, Ban, Play, Pause, Check, CheckCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchConversation, sendText, uploadAndSend, subscribeMessages,
  subscribeTyping, setTyping, markRead, getProfileDB, type DBMessage,
} from "@/lib/chat-api";
import { blockUserDB, isBlockedByMe } from "@/lib/blocks-api";
import { resolveMedia } from "@/lib/media-url";

export const Route = createFileRoute("/chat/$id")({ component: Chat });

const IMG_MAX = 5 * 1024 * 1024;
const AUD_MAX_DURATION = 60_000;

function Chat() {
  const { id: otherId } = Route.useParams();
  const navigate = useNavigate();
  const [myId, setMyId] = useState<string | null>(null);
  const [other, setOther] = useState<{ id: string; name: string; avatar_url: string | null; is_online: boolean; last_seen: string } | null>(null);
  const [messages, setMessages] = useState<DBMessage[]>([]);
  const [text, setText] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [theyTyping, setTheyTyping] = useState(false);
  const [sending, setSending] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recStartRef = useRef<number>(0);
  const recTimerRef = useRef<number | null>(null);
  const recAutoStopRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const typingTimerRef = useRef<number | null>(null);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return navigate({ to: "/auth" });
      setMyId(u.user.id);
      const blocked = await isBlockedByMe(u.user.id, otherId);
      if (blocked) { toast.error("هذا المستخدم محظور"); navigate({ to: "/settings" }); return; }
      const p = await getProfileDB(otherId);
      if (p) setOther(p as any);
      const msgs = await fetchConversation(u.user.id, otherId);
      setMessages(msgs);
      await markRead(u.user.id, otherId);

      const unsubMsg = subscribeMessages(u.user.id, (m) => {
        if ((m.sender_id === otherId && m.receiver_id === u.user!.id) ||
            (m.sender_id === u.user!.id && m.receiver_id === otherId)) {
          setMessages((prev) => {
            const idx = prev.findIndex((x) => x.id === m.id);
            if (idx >= 0) { const cp = [...prev]; cp[idx] = m; return cp; }
            return [...prev, m];
          });
          if (m.receiver_id === u.user!.id) markRead(u.user!.id, otherId);
        }
      });
      const unsubTyping = subscribeTyping(u.user.id, otherId, setTheyTyping);

      // subscribe to other's online status
      const chP = supabase.channel(`prof:${otherId}`)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${otherId}` },
          (p) => setOther((o) => o ? { ...o, ...(p.new as any) } : o))
        .subscribe();

      return () => { unsubMsg(); unsubTyping(); supabase.removeChannel(chP); };
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otherId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, theyTyping]);

  const onTypingChange = (v: string) => {
    setText(v);
    if (!myId) return;
    setTyping(myId, otherId, true);
    if (typingTimerRef.current) window.clearTimeout(typingTimerRef.current);
    typingTimerRef.current = window.setTimeout(() => setTyping(myId, otherId, false), 2000);
  };

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const t = text.trim();
    if (!t || !myId || sending) return;
    setSending(true);
    setText("");
    try { await sendText(myId, otherId, t); }
    catch (err: any) { toast.error(err?.message ?? "فشل الإرسال"); setText(t); }
    finally { setSending(false); }
  };

  const handleImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f || !myId) return;
    if (f.size > IMG_MAX) return toast.error("حجم الصورة أكبر من 5 ميغا");
    try {
      const ext = f.name.split(".").pop() || "jpg";
      await uploadAndSend(myId, otherId, f, "chat-media", ext, "image");
    } catch { toast.error("فشل رفع الصورة"); }
  };

  const startRec = async () => {
    if (recording) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mr = new MediaRecorder(stream);
      mediaRecRef.current = mr;
      chunksRef.current = [];
      mr.ondataavailable = (ev) => { if (ev.data.size) chunksRef.current.push(ev.data); };
      mr.onstop = async () => {
        const dur = Math.round((Date.now() - recStartRef.current) / 1000);
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        stream.getTracks().forEach((t) => t.stop());
        if (dur < 1) return; // ignore too-short
        if (!myId) return;
        try {
          await uploadAndSend(myId, otherId, blob, "voice-messages", "webm", "audio", dur);
        } catch {
          toast.error("فشل الإرسال، حاول مرة أخرى");
        }
      };
      mr.start();
      recStartRef.current = Date.now();
      setRecording(true);
      setRecSecs(0);
      recTimerRef.current = window.setInterval(() => {
        setRecSecs(Math.floor((Date.now() - recStartRef.current) / 1000));
      }, 250);
      recAutoStopRef.current = window.setTimeout(stopRec, AUD_MAX_DURATION);
    } catch { toast.error("تعذر الوصول للميكروفون"); }
  };

  const stopRec = () => {
    if (recTimerRef.current) clearInterval(recTimerRef.current);
    if (recAutoStopRef.current) clearTimeout(recAutoStopRef.current);
    recTimerRef.current = null;
    recAutoStopRef.current = null;
    if (mediaRecRef.current && mediaRecRef.current.state !== "inactive") mediaRecRef.current.stop();
    setRecording(false);
  };

  const doBlock = async () => {
    if (!myId || !other) return;
    if (!confirm(`حظر ${other.name}؟`)) return;
    try { await blockUserDB(myId, otherId); toast.success("تم الحظر"); navigate({ to: "/" }); }
    catch { toast.error("فشل الحظر"); }
  };

  const name = other?.name ?? "مستخدم";
  const statusLine = theyTyping
    ? "يكتب..."
    : other?.is_online
      ? "متصل الآن"
      : other?.last_seen
        ? `آخر ظهور ${new Date(other.last_seen).toLocaleTimeString("ar-LY", { hour: "2-digit", minute: "2-digit" })}`
        : "";

  return (
    <main className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-10 border-b border-border bg-card/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-md items-center gap-3 px-4 py-3">
          <Link to="/" className="rounded-full p-2 text-muted-foreground hover:bg-muted"><ArrowRight className="h-5 w-5" /></Link>
          <div className="flex h-10 w-10 items-center justify-center rounded-full text-sm font-black text-white" style={{ backgroundColor: "#8b5cf6" }}>
            {name.charAt(0)}
          </div>
          <div className="flex-1">
            <p className="font-bold leading-tight">{name}</p>
            <p className={`text-xs ${theyTyping ? "text-primary" : other?.is_online ? "text-emerald-600" : "text-muted-foreground"}`}>{statusLine}</p>
          </div>
          <div className="relative">
            <button onClick={() => setMenuOpen((v) => !v)} className="rounded-full p-2 text-muted-foreground hover:bg-muted"><MoreVertical className="h-5 w-5" /></button>
            {menuOpen && (
              <div className="absolute left-0 top-11 z-20 w-44 overflow-hidden rounded-xl bg-card shadow-xl ring-1 ring-border">
                <button onClick={() => { setMenuOpen(false); doBlock(); }} className="flex w-full items-center gap-2 px-4 py-2.5 text-right text-sm text-destructive hover:bg-muted">
                  <Ban className="h-4 w-4" /> حظر المستخدم
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div ref={scrollRef} className="mx-auto w-full max-w-md flex-1 space-y-3 overflow-y-auto px-4 py-6">
        {messages.length === 0 && (
          <p className="pt-10 text-center text-sm text-muted-foreground">ابدأ المحادثة بإرسال رسالة أو صورة</p>
        )}
        {messages.map((m) => {
          const mine = m.sender_id === myId;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-start" : "justify-end"}`}>
              <div style={{ backgroundColor: mine ? "#8b5cf6" : "#4b5563", color: "#fff" }}
                className={`max-w-[75%] rounded-2xl px-3 py-2 shadow-sm ${mine ? "rounded-tr-md" : "rounded-tl-md"}`}>
                {m.type === "image" && <MediaImage refPath={m.media_url!} />}
                {m.type === "audio" && <AudioBubble refPath={m.media_url!} duration={m.audio_duration ?? 0} />}
                {m.text && <p className="px-1 pt-1 text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>}
                <div className="mt-1 flex items-center justify-end gap-1 px-1">
                  <p className="text-[10px] text-white/70">
                    {new Date(m.created_at).toLocaleTimeString("ar-LY", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                  {mine && (m.read ? <CheckCheck className="h-3 w-3 text-cyan-200" /> : m.delivered ? <CheckCheck className="h-3 w-3 text-white/70" /> : <Check className="h-3 w-3 text-white/70" />)}
                </div>
              </div>
            </div>
          );
        })}
        {theyTyping && (
          <div className="flex justify-end">
            <div className="rounded-2xl bg-muted px-3 py-2 text-xs text-muted-foreground">يكتب...</div>
          </div>
        )}
      </div>

      <form onSubmit={send} className="sticky bottom-0 border-t border-border bg-card/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-md items-center gap-2 px-3 py-3">
          <input ref={imgInputRef} type="file" accept="image/*" className="hidden" onChange={handleImage} />
          {!recording ? (
            <>
              <button type="button" onClick={() => imgInputRef.current?.click()} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary hover:bg-primary/20"><ImageIcon className="h-5 w-5" /></button>
              <button type="button"
                onPointerDown={(e) => { e.preventDefault(); startRec(); }}
                onPointerUp={stopRec}
                onPointerLeave={() => recording && stopRec()}
                onPointerCancel={stopRec}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary hover:bg-primary/20 select-none touch-none"><Mic className="h-5 w-5" /></button>
              <input value={text} onChange={(e) => onTypingChange(e.target.value)} placeholder="اكتب رسالة…" className="min-w-0 flex-1 rounded-full border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary focus:ring-4 focus:ring-primary/15" />
              <button type="submit" disabled={sending} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-brand text-white shadow-md active:scale-95 disabled:opacity-50">
                <Send className="h-5 w-5 -scale-x-100" />
              </button>
            </>
          ) : (
            <div className="flex flex-1 items-center gap-3 rounded-full px-4 py-3 text-white" style={{ backgroundColor: "#8b5cf6" }}>
              <span className="h-3 w-3 animate-pulse rounded-full bg-red-500" />
              <span className="font-mono text-sm">{String(Math.floor(recSecs / 60))}:{String(recSecs % 60).padStart(2, "0")}</span>
              <span className="flex-1 text-xs">ارفع الإصبع للإرسال…</span>
              <Mic className="h-5 w-5" />
            </div>
          )}
        </div>
      </form>
    </main>
  );
}

function MediaImage({ refPath }: { refPath: string }) {
  const [url, setUrl] = useState("");
  useEffect(() => { resolveMedia(refPath).then(setUrl); }, [refPath]);
  return url ? <img src={url} alt="" style={{ maxWidth: 220 }} className="rounded-xl" /> : <div className="h-40 w-52 animate-pulse rounded-xl bg-white/20" />;
}

function AudioBubble({ refPath, duration }: { refPath: string; duration: number }) {
  const [url, setUrl] = useState("");
  const [playing, setPlaying] = useState(false);
  const ref = useRef<HTMLAudioElement>(null);
  useEffect(() => { resolveMedia(refPath).then(setUrl); }, [refPath]);
  const toggle = () => {
    const a = ref.current;
    if (!a) return;
    if (playing) { a.pause(); setPlaying(false); }
    else { a.play(); setPlaying(true); }
  };
  return (
    <div className="flex items-center gap-2 px-1 py-1">
      <button type="button" onClick={toggle} disabled={!url} className="flex h-8 w-8 items-center justify-center rounded-full bg-white/25 disabled:opacity-50">
        {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </button>
      <div className="flex h-6 w-32 items-center gap-0.5">
        {Array.from({ length: 22 }).map((_, i) => (
          <span key={i} className="w-0.5 rounded-full bg-white/80" style={{ height: `${6 + ((i * 37) % 16)}px`, opacity: 0.5 + ((i * 13) % 5) / 10 }} />
        ))}
      </div>
      <span className="font-mono text-[11px] text-white/85">{Math.floor(duration / 60)}:{String(duration % 60).padStart(2, "0")}</span>
      <audio ref={ref} src={url} onEnded={() => setPlaying(false)} className="hidden" preload="none" />
    </div>
  );
}
