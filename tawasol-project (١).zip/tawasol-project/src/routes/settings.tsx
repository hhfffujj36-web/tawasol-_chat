import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, User, Ban, LogOut } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { listBlocks, unblockUserDB } from "@/lib/blocks-api";
import { resolveMedia } from "@/lib/media-url";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const navigate = useNavigate();
  const [me, setMe] = useState<{ id: string; name: string; avatar_url: string | null } | null>(null);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [blocked, setBlocked] = useState<Array<{ blocked_id: string; profile: any }>>([]);

  const reload = async (uid: string) => {
    const b = await listBlocks(uid);
    setBlocked(b);
  };

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return navigate({ to: "/auth" });
      const { data: p } = await supabase.from("profiles").select("id,name,avatar_url").eq("id", u.user.id).maybeSingle();
      if (p) {
        setMe(p as any);
        if (p.avatar_url) setAvatarUrl(await resolveMedia(p.avatar_url));
      }
      await reload(u.user.id);
    })();
  }, [navigate]);

  const doUnblock = async (id: string) => {
    if (!me) return;
    await unblockUserDB(me.id, id);
    toast.success("تم إلغاء الحظر");
    await reload(me.id);
  };

  const doSignOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  return (
    <main className="min-h-screen bg-background">
      <header className="bg-gradient-brand px-5 py-6 text-white">
        <div className="mx-auto flex max-w-md items-center gap-3">
          <Link to="/" className="rounded-full bg-white/15 p-2 backdrop-blur-md"><ArrowRight className="h-5 w-5" /></Link>
          <h1 className="text-2xl font-black">الإعدادات</h1>
        </div>
      </header>

      <section className="mx-auto max-w-md space-y-4 px-5 py-8">
        <Link to="/profile" className="flex items-center gap-4 rounded-3xl bg-card p-5 ring-1 ring-border">
          <div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-primary/10 text-primary">
            {avatarUrl ? <img src={avatarUrl} alt="" className="h-full w-full object-cover" /> : <User className="h-7 w-7" />}
          </div>
          <div className="flex-1">
            <p className="text-sm text-muted-foreground">تعديل البروفايل</p>
            <p className="font-bold">{me?.name ?? "…"}</p>
          </div>
          <span className="text-2xl text-muted-foreground">‹</span>
        </Link>

        <div className="rounded-3xl bg-card p-5 ring-1 ring-border">
          <div className="mb-3 flex items-center gap-2">
            <Ban className="h-5 w-5 text-destructive" />
            <h2 className="font-bold">المحظورون</h2>
          </div>
          {blocked.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا يوجد مستخدمون محظورون</p>
          ) : (
            <ul className="space-y-2">
              {blocked.map((b) => {
                const name = b.profile?.name ?? "مستخدم";
                return (
                  <li key={b.blocked_id} className="flex items-center gap-3 rounded-xl bg-muted/50 p-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full text-sm font-black text-white" style={{ backgroundColor: "#8b5cf6" }}>
                      {name.charAt(0)}
                    </div>
                    <p className="flex-1 font-semibold">{name}</p>
                    <button onClick={() => doUnblock(b.blocked_id)} className="rounded-full bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary hover:bg-primary hover:text-primary-foreground">
                      إلغاء الحظر
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <button onClick={doSignOut} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/30 py-3 text-sm font-bold text-destructive">
          <LogOut className="h-4 w-4" /> تسجيل الخروج
        </button>
      </section>
    </main>
  );
}
