import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, MessageCircle } from "lucide-react";
import { getPhone } from "../lib/auth";
import { listConversations, type Conversation } from "../lib/chat-storage";

export const Route = createFileRoute("/chats")({
  component: Chats,
});

function lastPreview(c: Conversation) {
  const m = c.messages[c.messages.length - 1];
  if (!m) return "";
  if (m.text) return m.text;
  if (m.image) return "📷 صورة";
  if (m.video) return "🎥 فيديو";
  return "";
}

function Chats() {
  const navigate = useNavigate();
  const [convs, setConvs] = useState<Conversation[]>([]);

  useEffect(() => {
    if (!getPhone()) {
      navigate({ to: "/" });
      return;
    }
    setConvs(listConversations());
  }, [navigate]);

  return (
    <main className="min-h-screen bg-background">
      <header className="bg-gradient-brand px-5 py-6 text-white">
        <div className="mx-auto flex max-w-md items-center gap-3">
          <Link to="/" className="rounded-full bg-white/15 p-2 backdrop-blur-md">
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-black">المحادثات</h1>
        </div>
      </header>

      <section className="mx-auto max-w-md px-5 py-6">
        {convs.length === 0 ? (
          <div className="py-16 text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary/10">
              <MessageCircle className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-xl font-bold">لا توجد محادثات بعد</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              روح لصفحة "ابحث من حولك" وابدأ محادثة جديدة
            </p>
            <Link
              to="/discover"
              className="mt-6 inline-flex items-center justify-center rounded-full bg-gradient-brand px-6 py-3 text-sm font-bold text-white shadow-lg"
            >
              اكتشف الأشخاص القريبين
            </Link>
          </div>
        ) : (
          <ul className="space-y-2">
            {convs.map((c) => {
              const last = c.messages[c.messages.length - 1];
              return (
                <li key={c.userId}>
                  <Link
                    to="/chat/$id"
                    params={{ id: c.userId }}
                    className="flex items-center gap-3 rounded-2xl bg-card p-3 ring-1 ring-border transition hover:-translate-y-0.5 hover:shadow-md"
                  >
                    <div
                      className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-lg font-black text-white"
                      style={{ backgroundColor: "#8b5cf6" }}
                    >
                      {c.name.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="truncate font-bold">{c.name}</p>
                        <span className="shrink-0 text-[11px] text-muted-foreground">
                          {last?.time}
                        </span>
                      </div>
                      <p className="truncate text-xs text-muted-foreground">
                        {lastPreview(c)}
                      </p>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </main>
  );
}
