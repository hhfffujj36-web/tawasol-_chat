import { createFileRoute } from "@tanstack/react-router";
import { CircleDot } from "lucide-react";
import BottomNav from "../components/BottomNav";

export const Route = createFileRoute("/status")({ component: Status });

function Status() {
  return (
    <main className="min-h-screen bg-background pb-24">
      <header className="bg-gradient-brand px-5 py-6 text-white">
        <div className="mx-auto max-w-md">
          <h1 className="text-2xl font-black">التحديثات</h1>
        </div>
      </header>
      <section className="mx-auto flex max-w-md flex-col items-center px-5 py-20 text-center">
        <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-3xl bg-primary/10">
          <CircleDot className="h-12 w-12 text-primary" />
        </div>
        <p className="text-lg font-bold">الستوري يظهر هنا</p>
      </section>
      <BottomNav />
    </main>
  );
}
