import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ensureGuestSession, getGuestName } from "@/lib/guest-auth";

export const Route = createFileRoute("/")({ component: Room });

type Msg = {
  id: string;
  user_id: string;
  user_name: string;
  text: string;
  created_at: string;
};

const ROOM = "general";

function Room() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [me, setMe] = useState<{ id: string; name: string } | null>(null);
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let cancelled = false;

    (async () => {
      await ensureGuestSession();
      const { data: u } = await supabase.auth.getUser();
      if (!u.user || cancelled) return;
      const name = getGuestName();
      setMe({ id: u.user.id, name });

      const { data } = await supabase
        .from("room_messages")
        .select("id,user_id,user_name,text,created_at")
        .eq("room", ROOM)
        .order("created_at", { ascending: true })
        .limit(200);
      if (!cancelled) setMsgs((data ?? []) as Msg[]);

      channel = supabase
        .channel(`room:${ROOM}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "room_messages",
            filter: `room=eq.${ROOM}`,
          },
          (p) => {
            const m = p.new as Msg;
            setMsgs((prev) =>
              prev.some((x) => x.id === m.id) ? prev : [...prev, m],
            );
          },
        )
        .subscribe();
    })();

    return () => {
      cancelled = true;
      if (channel) supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [msgs]);

  const send = async () => {
    const t = text.trim();
    if (!t || !me || sending) return;
    setSending(true);
    setText("");
    const { error } = await supabase.from("room_messages").insert({
      room: ROOM,
      user_id: me.id,
      user_name: me.name,
      text: t,
    });
    setSending(false);
    if (error) {
      setText(t);
      console.error(error);
    }
  };

  return (
    <main className="flex h-[100dvh] flex-col bg-background">
      <header className="bg-gradient-brand px-4 py-4 text-white shadow-lg">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <div>
            <div className="text-xs opacity-80">الغرفة</div>
            <h1 className="text-2xl font-black">عام</h1>
          </div>
          {me && (
            <div className="text-left text-xs opacity-90">
              <div className="opacity-70">أنت</div>
              <div className="font-bold">{me.name}</div>
            </div>
          )}
        </div>
      </header>

      <div ref={scrollRef} className="mx-auto w-full max-w-md flex-1 overflow-y-auto px-3 py-4 space-y-2">
        {msgs.length === 0 ? (
          <p className="mt-10 text-center text-sm text-muted-foreground">
            لا توجد رسائل بعد. ابدأ المحادثة!
          </p>
        ) : (
          msgs.map((m) => {
            const mine = me?.id === m.user_id;
            return (
              <div key={m.id} className={`flex ${mine ? "justify-start" : "justify-end"}`}>
                <div
                  className={`max-w-[75%] rounded-2xl px-3 py-2 shadow-sm ${
                    mine
                      ? "bg-primary text-primary-foreground"
                      : "bg-card ring-1 ring-border"
                  }`}
                >
                  {!mine && (
                    <div className="mb-0.5 text-[11px] font-bold opacity-70">
                      {m.user_name}
                    </div>
                  )}
                  <div className="whitespace-pre-wrap break-words text-sm">{m.text}</div>
                  <div className={`mt-1 text-[10px] ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                    {new Date(m.created_at).toLocaleTimeString("ar-LY", { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="border-t border-border bg-card">
        <div className="mx-auto flex max-w-md items-center gap-2 p-3">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="اكتب رسالة..."
            className="flex-1 rounded-full bg-muted px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary"
          />
          <button
            onClick={send}
            disabled={!text.trim() || sending}
            className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
            aria-label="إرسال"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>
    </main>
  );
}
