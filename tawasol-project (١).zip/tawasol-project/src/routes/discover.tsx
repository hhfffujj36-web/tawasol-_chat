import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MapPin, Search, MessageCircle, EyeOff, Eye, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { fetchNearby, updateMyLocation, setHideLocation, type NearbyRow } from "@/lib/location-api";
import { resolveMedia } from "@/lib/media-url";
import BottomNav from "../components/BottomNav";

export const Route = createFileRoute("/discover")({ component: Discover });

function Avatar({ name, ref: refPath }: { name: string; ref: string | null }) {
  const [url, setUrl] = useState("");
  useEffect(() => { if (refPath) resolveMedia(refPath).then(setUrl); }, [refPath]);
  return (
    <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-full text-lg font-black text-white" style={{ backgroundColor: "#8B5CF6" }}>
      {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : name.charAt(0)}
    </div>
  );
}

function Discover() {
  const navigate = useNavigate();
  const [users, setUsers] = useState<NearbyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [hideMe, setHideMe] = useState(false);
  const [radius, setRadius] = useState(5);

  const load = async () => {
    setLoading(true);
    try {
      await updateMyLocation();
      const rows = await fetchNearby(radius);
      setUsers(rows);
    } catch (e: any) {
      toast.error(e?.message ?? "تعذر جلب الموقع");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return navigate({ to: "/auth" });
      const { data: p } = await supabase.from("profiles").select("hide_location").eq("id", u.user.id).maybeSingle();
      setHideMe(!!p?.hide_location);
      await load();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleHide = async () => {
    const next = !hideMe;
    setHideMe(next);
    await setHideLocation(next);
    toast.success(next ? "تم إخفاء موقعك" : "موقعك ظاهر الآن");
  };

  const visible = users
    .filter((u) => (q.trim() ? u.name.includes(q.trim()) || (u.phone ?? "").includes(q.trim()) : true))
    .sort((a, b) => a.distance_km - b.distance_km);

  return (
    <main className="min-h-screen bg-background pb-24">
      <header className="bg-gradient-brand px-5 py-5 text-white">
        <div className="mx-auto flex max-w-md items-center justify-between">
          <h1 className="text-2xl font-black">من حولك</h1>
          <div className="flex items-center gap-1">
            <button onClick={toggleHide} className="rounded-full p-2 hover:bg-white/15" aria-label="إخفاء">
              {hideMe ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
            <button onClick={load} className="rounded-full p-2 hover:bg-white/15" aria-label="تحديث">
              <RefreshCw className={`h-5 w-5 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
        <div className="mx-auto mt-3 flex max-w-md items-center gap-2 rounded-2xl bg-white/15 px-3 py-2 backdrop-blur-md">
          <Search className="h-4 w-4 text-white/80" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث بالاسم أو الرقم..." className="w-full bg-transparent text-sm text-white placeholder:text-white/60 outline-none" />
        </div>
      </header>

      <section className="mx-auto max-w-md px-5 py-5">
        <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl bg-primary/10 p-4 ring-1 ring-primary/20">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            <p className="text-sm font-bold text-primary">ضمن {radius} كم</p>
          </div>
          <div className="flex gap-1">
            {[1, 5, 10, 20].map((r) => (
              <button key={r} onClick={() => { setRadius(r); setTimeout(load, 0); }} className={`rounded-full px-3 py-1 text-xs font-bold ${radius === r ? "bg-primary text-white" : "bg-white text-primary"}`}>{r}</button>
            ))}
          </div>
        </div>

        {hideMe && (
          <div className="mb-4 rounded-xl bg-amber-100 p-3 text-xs font-bold text-amber-800 ring-1 ring-amber-300">
            موقعك مخفي — الآخرون لا يرونك لكنك ما زلت ترى الآخرين.
          </div>
        )}

        {loading ? (
          <p className="py-10 text-center text-sm text-muted-foreground">جاري تحديد موقعك...</p>
        ) : visible.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">لا يوجد أشخاص قريبون الآن</p>
        ) : (
          <ul className="space-y-2">
            {visible.map((u) => (
              <li key={u.id} className="flex items-center gap-3 rounded-2xl bg-card p-3 ring-1 ring-border">
                <div className="relative">
                  <Avatar name={u.name} ref={u.avatar_url} />
                  {u.is_online && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-card" />}
                </div>
                <div className="flex-1">
                  <p className="font-bold">{u.name}</p>
                  <p className="text-xs text-muted-foreground"><span dir="ltr">{u.distance_km.toFixed(2)}</span> كم</p>
                </div>
                <Link to="/chat/$id" params={{ id: u.id }} className="flex items-center gap-1 rounded-full px-3 py-2 text-xs font-bold text-white" style={{ backgroundColor: "#8B5CF6" }}>
                  <MessageCircle className="h-3.5 w-3.5" /> مراسلة
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <BottomNav />
    </main>
  );
}
