import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Users, MessageSquare, MapPin, Shield } from "lucide-react";
import { getPhone, isAdmin } from "../lib/auth";
import { allUsers } from "../lib/mock-users";

export const Route = createFileRoute("/admin")({
  component: Admin,
});

function Admin() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const p = getPhone();
    if (!isAdmin(p)) {
      navigate({ to: "/home" });
      return;
    }
    setReady(true);
  }, [navigate]);

  if (!ready) return null;

  const stats = [
    { label: "المستخدمين", value: allUsers.length, icon: Users, color: "from-indigo-500 to-violet-500" },
    { label: "المحادثات", value: 42, icon: MessageSquare, color: "from-fuchsia-500 to-pink-500" },
    { label: "متصلين الآن", value: 6, icon: MapPin, color: "from-emerald-500 to-teal-500" },
  ];

  return (
    <main className="min-h-screen bg-slate-50">
      <header className="bg-slate-900 px-5 py-6 text-white">
        <div className="mx-auto flex max-w-4xl items-center gap-3">
          <Link to="/" className="rounded-full bg-white/10 p-2">
            <ArrowRight className="h-5 w-5" />
          </Link>
          <Shield className="h-6 w-6" />
          <div>
            <h1 className="text-2xl font-black">لوحة الأدمن</h1>
            <p className="text-xs text-white/70">إدارة تطبيق تواصل</p>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-4xl px-5 py-6">
        <div className="grid gap-3 sm:grid-cols-3">
          {stats.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="rounded-3xl bg-card p-5 ring-1 ring-border">
              <div className={`mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${color} text-white`}>
                <Icon className="h-5 w-5" />
              </div>
              <p className="text-3xl font-black">{value}</p>
              <p className="text-sm text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 overflow-hidden rounded-3xl bg-card ring-1 ring-border">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h2 className="text-lg font-bold">قائمة المستخدمين</h2>
            <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
              {allUsers.length}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 text-right">#</th>
                  <th className="px-5 py-3 text-right">الاسم</th>
                  <th className="px-5 py-3 text-right">الرقم</th>
                  <th className="px-5 py-3 text-right">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {allUsers.map((u, i) => (
                  <tr key={u.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-5 py-3 text-muted-foreground">{i + 1}</td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-brand text-xs font-bold text-white">
                          {u.avatar}
                        </div>
                        <span className="font-semibold">{u.name}</span>
                      </div>
                    </td>
                    <td dir="ltr" className="px-5 py-3 text-right font-mono text-muted-foreground">
                      {u.phone}
                    </td>
                    <td className="px-5 py-3">
                      {u.phone === "0910000000" ? (
                        <span className="rounded-full bg-slate-900 px-2.5 py-1 text-xs font-bold text-white">
                          أدمن
                        </span>
                      ) : (
                        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-700">
                          نشط
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>
  );
}
