import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Camera, Sparkles, User, LogOut } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { resolveMedia } from "@/lib/media-url";

export const Route = createFileRoute("/profile")({ component: ProfilePage });

const AVATAR_MAX = 2 * 1024 * 1024;

function ProfilePage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [avatarPreview, setAvatarPreview] = useState<string>("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarRef, setAvatarRef] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return navigate({ to: "/auth" });
      setUserId(u.user.id);
      const { data: p } = await supabase.from("profiles").select("name,avatar_url").eq("id", u.user.id).maybeSingle();
      if (p) {
        setName(p.name ?? "");
        if (p.avatar_url) {
          setAvatarRef(p.avatar_url);
          setAvatarPreview(await resolveMedia(p.avatar_url));
        }
      }
    })();
  }, [navigate]);

  const pickAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > AVATAR_MAX) return toast.error("حجم الصورة أكبر من 2 ميغا");
    setAvatarFile(f);
    setAvatarPreview(URL.createObjectURL(f));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId) return;
    if (name.trim().length < 2) return toast.error("الاسم قصير جداً");
    setBusy(true);
    try {
      let ref = avatarRef;
      if (avatarFile) {
        const ext = avatarFile.name.split(".").pop() || "jpg";
        const path = `${userId}/${crypto.randomUUID()}.${ext}`;
        const up = await supabase.storage.from("avatars").upload(path, avatarFile, { contentType: avatarFile.type });
        if (up.error) throw up.error;
        ref = `avatars:${path}`;
      }
      await supabase.from("profiles").update({ name: name.trim(), avatar_url: ref }).eq("id", userId);
      toast.success("تم الحفظ");
      navigate({ to: "/" });
    } catch (err: any) {
      toast.error(err?.message ?? "فشل الحفظ");
    } finally {
      setBusy(false);
    }
  };

  const doSignOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-gradient-brand">
      <div className="pointer-events-none absolute -top-40 -right-32 h-96 w-96 rounded-full bg-white/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-32 h-96 w-96 rounded-full bg-fuchsia-400/30 blur-3xl" />
      <div className="relative z-10 mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-10">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md ring-1 ring-white/40">
            <Sparkles className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-3xl font-black text-white">ملفك الشخصي</h1>
        </div>
        <div className="rounded-3xl bg-white/95 p-6 shadow-2xl">
          <form onSubmit={submit} className="space-y-5">
            <div className="flex flex-col items-center">
              <button type="button" onClick={() => fileRef.current?.click()} className="relative flex h-24 w-24 items-center justify-center overflow-hidden rounded-full bg-gradient-brand text-3xl font-black text-white ring-4 ring-white/60">
                {avatarPreview ? <img src={avatarPreview} alt="" className="h-full w-full object-cover" /> : name.trim() ? name.trim().charAt(0) : <User className="h-10 w-10" />}
                <span className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-white text-primary shadow-md"><Camera className="h-4 w-4" /></span>
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={pickAvatar} />
            </div>
            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-foreground/80">الاسم</span>
              <input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-2xl border border-border bg-background px-4 py-4 text-lg font-semibold outline-none focus:border-primary focus:ring-4 focus:ring-primary/20" />
            </label>
            <button type="submit" disabled={busy} className="w-full rounded-2xl bg-gradient-brand py-4 text-lg font-bold text-white shadow-lg shadow-indigo-700/30 active:scale-[0.98] disabled:opacity-70">
              {busy ? "..." : "حفظ"}
            </button>
            <button type="button" onClick={doSignOut} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/30 py-3 text-sm font-bold text-destructive">
              <LogOut className="h-4 w-4" /> تسجيل الخروج
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}
