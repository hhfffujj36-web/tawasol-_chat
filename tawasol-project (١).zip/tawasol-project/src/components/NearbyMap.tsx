import { useEffect, useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { User } from "../lib/mock-users";

type Point = { user: User; lat: number; lng: number };

function Recenter({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

export default function NearbyMap({
  users,
  onSelectUser,
}: {
  users: User[];
  onSelectUser: (id: string) => void;
}) {
  const [me, setMe] = useState<[number, number]>([32.8872, 13.1913]); // Tripoli default
  const [points, setPoints] = useState<Point[]>([]);

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setMe([pos.coords.latitude, pos.coords.longitude]),
      () => {},
      { timeout: 5000 },
    );
  }, []);

  useEffect(() => {
    // scatter users around me within ~1km
    const pts = users.map((u) => {
      const r = 0.003 + Math.random() * 0.007;
      const a = Math.random() * Math.PI * 2;
      return { user: u, lat: me[0] + r * Math.cos(a), lng: me[1] + r * Math.sin(a) };
    });
    setPoints(pts);
  }, [users, me]);

  return (
    <MapContainer
      center={me}
      zoom={15}
      style={{ height: 200, width: "100%" }}
      className="overflow-hidden rounded-3xl ring-1 ring-border"
      scrollWheelZoom={false}
    >
      <Recenter center={me} />
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; OpenStreetMap &copy; CARTO'
      />
      <CircleMarker
        center={me}
        radius={9}
        pathOptions={{ color: "#3b82f6", fillColor: "#3b82f6", fillOpacity: 1, weight: 3 }}
      >
        <Popup>موقعي</Popup>
      </CircleMarker>
      {points.map((p) => (
        <CircleMarker
          key={p.user.id}
          center={[p.lat, p.lng]}
          radius={8}
          pathOptions={{ color: "#8b5cf6", fillColor: "#8b5cf6", fillOpacity: 0.9, weight: 2 }}
          eventHandlers={{ click: () => onSelectUser(p.user.id) }}
        >
          <Popup>{p.user.name}</Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
