import { Link, useRouterState } from "@tanstack/react-router";
import { MessageCircle, Users, Phone, CircleDot, Grid3X3 } from "lucide-react";

const items = [
  { to: "/", label: "الدردشات", Icon: MessageCircle },
  { to: "/discover", label: "من حولك", Icon: Users },
  { to: "/calls", label: "المكالمات", Icon: Phone },
  { to: "/status", label: "التحديثات", Icon: CircleDot },
  { to: "/tools", label: "الأدوات", Icon: Grid3X3 },
] as const;

export default function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-card/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
        {items.map(({ to, label, Icon }) => {
          const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              className="flex flex-1 flex-col items-center gap-1 rounded-xl py-1.5"
              style={{ color: active ? "#8B5CF6" : "#9CA3AF" }}
            >
              <Icon className="h-5 w-5" />
              <span className={`text-[11px] ${active ? "font-bold" : "font-medium"}`}>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
