import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";

type BIPEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const DISMISS_KEY = "pwa_install_dismissed";

export default function InstallPWA() {
  const [deferred, setDeferred] = useState<BIPEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      // @ts-ignore iOS Safari
      window.navigator.standalone === true;
    if (standalone) return;

    const dismissed = localStorage.getItem(DISMISS_KEY);
    if (dismissed && Date.now() - Number(dismissed) < 1000 * 60 * 60 * 24 * 3) return;

    const ua = window.navigator.userAgent.toLowerCase();
    const iOS = /iphone|ipad|ipod/.test(ua) && !/crios|fxios/.test(ua);
    if (iOS) {
      setIsIOS(true);
      setVisible(true);
      return;
    }

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BIPEvent);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", () => setVisible(false));
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  if (!visible) return null;

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    setDeferred(null);
    setVisible(false);
  };

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, String(Date.now()));
    setVisible(false);
  };

  return (
    <div className="mx-auto mt-3 max-w-md px-3">
      <div
        className="relative flex items-center gap-3 rounded-2xl p-3 text-white shadow-lg backdrop-blur-md"
        style={{
          background: "linear-gradient(135deg, rgba(139,92,246,0.95), rgba(167,139,250,0.95))",
          boxShadow: "0 10px 30px rgba(139,92,246,0.35)",
        }}
      >
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/20">
          <Download className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold">ثبّت تطبيق تواصل</p>
          <p className="truncate text-[11px] text-white/85">
            {isIOS
              ? "اضغط زر المشاركة ثم «إضافة إلى الشاشة الرئيسية»"
              : "افتحه كتطبيق مستقل من الشاشة الرئيسية"}
          </p>
        </div>
        {!isIOS && (
          <button
            onClick={install}
            className="shrink-0 rounded-xl bg-white/95 px-3 py-1.5 text-xs font-bold text-primary hover:bg-white"
          >
            تثبيت
          </button>
        )}
        <button
          onClick={dismiss}
          aria-label="إغلاق"
          className="shrink-0 rounded-lg p-1 hover:bg-white/15"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
