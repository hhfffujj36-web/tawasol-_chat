import { supabase } from "@/integrations/supabase/client";

export type DBMessage = {
  id: string;
  sender_id: string;
  receiver_id: string;
  text: string | null;
  type: "text" | "image" | "audio";
  media_url: string | null;
  audio_duration: number | null;
  delivered: boolean;
  read: boolean;
  created_at: string;
};

export async function fetchConversation(myId: string, otherId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .or(
      `and(sender_id.eq.${myId},receiver_id.eq.${otherId}),and(sender_id.eq.${otherId},receiver_id.eq.${myId})`,
    )
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as DBMessage[];
}

export async function sendText(myId: string, otherId: string, text: string) {
  const { error } = await supabase.from("messages").insert({
    sender_id: myId,
    receiver_id: otherId,
    text,
    type: "text",
    delivered: true,
  });
  if (error) throw error;
}

export async function uploadAndSend(
  myId: string,
  otherId: string,
  file: Blob,
  bucket: "chat-media" | "voice-messages",
  ext: string,
  type: "image" | "audio",
  audioDuration?: number,
) {
  const path = `${myId}/${crypto.randomUUID()}.${ext}`;
  const up = await supabase.storage.from(bucket).upload(path, file, { contentType: file.type });
  if (up.error) throw up.error;
  const mediaRef = `${bucket}:${path}`;
  const { error } = await supabase.from("messages").insert({
    sender_id: myId,
    receiver_id: otherId,
    type,
    media_url: mediaRef,
    audio_duration: audioDuration ?? null,
    delivered: true,
  });
  if (error) throw error;
}

export async function markRead(myId: string, otherId: string) {
  await supabase
    .from("messages")
    .update({ read: true })
    .eq("receiver_id", myId)
    .eq("sender_id", otherId)
    .eq("read", false);
}

export function subscribeMessages(myId: string, cb: (m: DBMessage) => void) {
  const ch = supabase
    .channel(`msg:${myId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages", filter: `receiver_id=eq.${myId}` },
      (p) => cb(p.new as DBMessage),
    )
    .on(
      "postgres_changes",
      { event: "UPDATE", schema: "public", table: "messages", filter: `sender_id=eq.${myId}` },
      (p) => cb(p.new as DBMessage),
    )
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}

export async function setTyping(myId: string, otherId: string, typing: boolean) {
  await supabase.from("typing_status").upsert({
    user_id: myId,
    chat_with: otherId,
    is_typing: typing,
    updated_at: new Date().toISOString(),
  });
}

export function subscribeTyping(myId: string, otherId: string, cb: (t: boolean) => void) {
  const ch = supabase
    .channel(`typ:${myId}:${otherId}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "typing_status", filter: `user_id=eq.${otherId}` },
      (p) => {
        const row: any = p.new;
        if (row && row.chat_with === myId) cb(!!row.is_typing);
      },
    )
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}

export async function listConversationsDB(myId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .or(`sender_id.eq.${myId},receiver_id.eq.${myId}`)
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw error;
  const groups = new Map<string, DBMessage>();
  for (const m of (data ?? []) as DBMessage[]) {
    const other = m.sender_id === myId ? m.receiver_id : m.sender_id;
    if (!groups.has(other)) groups.set(other, m);
  }
  return Array.from(groups.entries()).map(([otherId, last]) => ({ otherId, last }));
}

export async function fetchProfiles(ids: string[]) {
  if (ids.length === 0) return [];
  const { data, error } = await supabase
    .from("profiles")
    .select("id,name,avatar_url,is_online,last_seen,phone")
    .in("id", ids);
  if (error) throw error;
  return data ?? [];
}

export async function getProfileDB(id: string) {
  const { data } = await supabase
    .from("profiles")
    .select("id,name,avatar_url,is_online,last_seen,phone,hide_location")
    .eq("id", id)
    .maybeSingle();
  return data;
}
