export type User = {
  id: string;
  name: string;
  avatar: string;
  distance: number;
  phone: string;
};

export const nearbyUsers: User[] = [
  { id: "1", name: "أحمد الطرابلسي", avatar: "أ", distance: 120, phone: "0911234567" },
  { id: "2", name: "سارة بن علي", avatar: "س", distance: 300, phone: "0912345678" },
  { id: "3", name: "محمد المصراتي", avatar: "م", distance: 450, phone: "0913456789" },
  { id: "4", name: "ليلى القذافي", avatar: "ل", distance: 600, phone: "0914567890" },
  { id: "5", name: "يوسف البنغازي", avatar: "ي", distance: 780, phone: "0915678901" },
  { id: "6", name: "فاطمة الزاوية", avatar: "ف", distance: 900, phone: "0916789012" },
];

export const allUsers = [
  ...nearbyUsers,
  { id: "admin", name: "الأدمن", avatar: "أد", distance: 0, phone: "0910000000" },
];
