export type UserProfile = { name: string; avatar?: string };

const PROFILE_KEY = "userProfile";
const BLOCKED_KEY = "blockedUsers";

export function getProfile(): UserProfile | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(PROFILE_KEY);
    return raw ? (JSON.parse(raw) as UserProfile) : null;
  } catch {
    return null;
  }
}

export function saveProfile(p: UserProfile) {
  window.localStorage.setItem(PROFILE_KEY, JSON.stringify(p));
}

export function getBlocked(): string[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(BLOCKED_KEY) || "[]");
  } catch {
    return [];
  }
}

export function blockUser(id: string) {
  const b = new Set(getBlocked());
  b.add(id);
  window.localStorage.setItem(BLOCKED_KEY, JSON.stringify([...b]));
}

export function unblockUser(id: string) {
  const b = getBlocked().filter((x) => x !== id);
  window.localStorage.setItem(BLOCKED_KEY, JSON.stringify(b));
}

export function isBlocked(id: string) {
  return getBlocked().includes(id);
}
