import { supabase } from "@/integrations/supabase/client";

export async function updateMyLocation() {
  return new Promise<{ lat: number; lng: number }>((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error("GPS غير مدعوم"));
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const { data: u } = await supabase.auth.getUser();
        if (!u.user) return reject(new Error("غير مسجّل الدخول"));
        await supabase
          .from("profiles")
          .update({ lat, lng, location_updated_at: new Date().toISOString() })
          .eq("id", u.user.id);
        resolve({ lat, lng });
      },
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
    );
  });
}

export async function setHideLocation(hide: boolean) {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) return;
  await supabase.from("profiles").update({ hide_location: hide }).eq("id", u.user.id);
}

export type NearbyRow = {
  id: string;
  name: string;
  avatar_url: string | null;
  phone: string | null;
  is_online: boolean;
  last_seen: string;
  distance_km: number;
};

export async function fetchNearby(radiusKm = 5): Promise<NearbyRow[]> {
  const { data, error } = await supabase.rpc("nearby_users", { radius_km: radiusKm });
  if (error) throw error;
  return (data ?? []) as NearbyRow[];
}
