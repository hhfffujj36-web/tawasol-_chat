export type Story = {
  type: "image" | "video";
  data: string; // base64
  timestamp: number;
};

const KEY = "myStory";
const DAY = 24 * 60 * 60 * 1000;

export function getMyStory(): Story | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Story;
    if (Date.now() - s.timestamp > DAY) {
      window.localStorage.removeItem(KEY);
      return null;
    }
    return s;
  } catch {
    return null;
  }
}

export function saveMyStory(s: Story) {
  window.localStorage.setItem(KEY, JSON.stringify(s));
}

export function deleteMyStory() {
  window.localStorage.removeItem(KEY);
}
