export const PHONE_KEY = "tawasol_phone";
export const NAME_KEY = "tawasol_name";

export function getPhone(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(PHONE_KEY);
}

export function setPhone(phone: string) {
  window.localStorage.setItem(PHONE_KEY, phone);
}

export function clearAuth() {
  window.localStorage.removeItem(PHONE_KEY);
}

export function isAdmin(phone: string | null) {
  return phone === "0910000000";
}

// Libyan phone: 09XXXXXXXX (10 digits, starts with 09)
export function isValidLibyanPhone(phone: string) {
  return /^09\d{8}$/.test(phone);
}
