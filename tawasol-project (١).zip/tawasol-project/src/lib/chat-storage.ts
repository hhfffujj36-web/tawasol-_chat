import { nearbyUsers, type User } from "./mock-users";

export type Msg = {
  id: string;
  text?: string;
  image?: string; // base64
  video?: string; // base64
  audio?: string; // base64
  audioDuration?: number;
  fromMe: boolean;
  time: string;
  ts: number;
};

export type Conversation = {
  userId: string;
  name: string;
  avatar: string;
  messages: Msg[];
};

const KEY = "tawasol_chats_v1";

export function loadChats(): Record<string, Conversation> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(KEY) || "{}");
  } catch {
    return {};
  }
}

export function saveChats(chats: Record<string, Conversation>) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(chats));
  } catch (e) {
    console.error("localStorage full", e);
  }
}

export function getConversation(userId: string): Conversation {
  const all = loadChats();
  if (all[userId]) return all[userId];
  const u = nearbyUsers.find((x) => x.id === userId);
  return {
    userId,
    name: u?.name ?? "مستخدم",
    avatar: u?.avatar ?? "؟",
    messages: [],
  };
}

export function saveConversation(conv: Conversation) {
  const all = loadChats();
  all[conv.userId] = conv;
  saveChats(all);
}

export function listConversations(): Conversation[] {
  const all = loadChats();
  return Object.values(all)
    .filter((c) => c.messages.length > 0)
    .sort((a, b) => {
      const at = a.messages[a.messages.length - 1]?.ts ?? 0;
      const bt = b.messages[b.messages.length - 1]?.ts ?? 0;
      return bt - at;
    });
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export function nowTime() {
  return new Date().toLocaleTimeString("ar-LY", { hour: "2-digit", minute: "2-digit" });
}

export type { User };
