import { supabase } from "@/integrations/supabase/client";

const GUEST_KEY = "tawasol_guest_creds_v1";
const NAME_KEY = "tawasol_guest_name_v1";

type GuestCreds = { email: string; password: string; name: string };

function loadCreds(): GuestCreds | null {
  try {
    const raw = localStorage.getItem(GUEST_KEY);
    return raw ? (JSON.parse(raw) as GuestCreds) : null;
  } catch {
    return null;
  }
}

function saveCreds(c: GuestCreds) {
  localStorage.setItem(GUEST_KEY, JSON.stringify(c));
  localStorage.setItem(NAME_KEY, c.name);
}

function randomName(): string {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `مستخدم${n}`;
}

function newCreds(): GuestCreds {
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
  return {
    email: `guest_${id}@tawasol.app`,
    password: `g_${crypto.randomUUID()}`,
    name: randomName(),
  };
}

export function getGuestName(): string {
  return localStorage.getItem(NAME_KEY) || "ضيف";
}

/** Ensure there is an authenticated session. If not, create/sign in a per-device guest. */
export async function ensureGuestSession(): Promise<void> {
  const { data: s } = await supabase.auth.getSession();
  if (s.session) return;

  let creds = loadCreds();
  if (creds) {
    const { error } = await supabase.auth.signInWithPassword({
      email: creds.email,
      password: creds.password,
    });
    if (!error) return;
  }
  creds = newCreds();
  const { data, error } = await supabase.auth.signUp({
    email: creds.email,
    password: creds.password,
    options: { data: { name: creds.name } },
  });
  if (error) throw error;
  saveCreds(creds);
  const uid = data.user?.id;
  if (uid) {
    await supabase.from("profiles").upsert({ id: uid, name: creds.name });
  }
  if (!data.session) {
    await supabase.auth.signInWithPassword({
      email: creds.email,
      password: creds.password,
    });
  }
}
