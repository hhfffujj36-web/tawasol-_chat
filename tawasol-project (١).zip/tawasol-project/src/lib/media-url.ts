import { supabase } from "@/integrations/supabase/client";

const cache = new Map<string, { url: string; exp: number }>();

// pathWithBucket format: "bucket:path/inside/bucket"
export async function resolveMedia(pathWithBucket: string): Promise<string> {
  if (!pathWithBucket) return "";
  if (pathWithBucket.startsWith("data:") || pathWithBucket.startsWith("http")) return pathWithBucket;
  const hit = cache.get(pathWithBucket);
  const now = Date.now();
  if (hit && hit.exp > now + 60_000) return hit.url;
  const idx = pathWithBucket.indexOf(":");
  if (idx < 0) return "";
  const bucket = pathWithBucket.slice(0, idx);
  const path = pathWithBucket.slice(idx + 1);
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60 * 24);
  if (error || !data) return "";
  cache.set(pathWithBucket, { url: data.signedUrl, exp: now + 60 * 60 * 24 * 1000 });
  return data.signedUrl;
}
