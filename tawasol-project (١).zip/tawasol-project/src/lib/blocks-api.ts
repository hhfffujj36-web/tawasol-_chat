import { supabase } from "@/integrations/supabase/client";

export async function blockUserDB(blockerId: string, blockedId: string) {
  const { error } = await supabase
    .from("blocks")
    .insert({ blocker_id: blockerId, blocked_id: blockedId });
  if (error && !String(error.message).includes("duplicate")) throw error;
}

export async function unblockUserDB(blockerId: string, blockedId: string) {
  await supabase.from("blocks").delete().eq("blocker_id", blockerId).eq("blocked_id", blockedId);
}

export async function listBlocks(blockerId: string) {
  const { data, error } = await supabase
    .from("blocks")
    .select("blocked_id, profiles!blocks_blocked_id_fkey(id,name,avatar_url,phone)")
    .eq("blocker_id", blockerId);
  if (error) {
    // fallback without FK join
    const b = await supabase.from("blocks").select("blocked_id").eq("blocker_id", blockerId);
    const ids = (b.data ?? []).map((x: any) => x.blocked_id);
    if (ids.length === 0) return [];
    const p = await supabase.from("profiles").select("id,name,avatar_url,phone").in("id", ids);
    return (p.data ?? []).map((pr: any) => ({ blocked_id: pr.id, profile: pr }));
  }
  return (data ?? []).map((r: any) => ({ blocked_id: r.blocked_id, profile: r.profiles }));
}

export async function isBlockedByMe(blockerId: string, otherId: string) {
  const { data } = await supabase
    .from("blocks")
    .select("blocker_id")
    .eq("blocker_id", blockerId)
    .eq("blocked_id", otherId)
    .maybeSingle();
  return !!data;
}
