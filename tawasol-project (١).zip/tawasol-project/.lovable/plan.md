## المطلوب

تحويل "تواصل" من تطبيق محلي (localStorage) إلى تطبيق حقيقي على Lovable Cloud مع شات لحظي، مواقع GPS، رسائل صوتية، وحظر — كل ذلك بالبناء فوق الكود الحالي بدون إعادة كتابة.

## قاعدة البيانات (Migration)

جداول جديدة في `public`:

- `profiles` — `id (uuid, FK auth.users)`, `phone (unique)`, `name`, `avatar_url`, `is_online (bool)`, `last_seen (timestamptz)`, `hide_location (bool default false)`, `lat (double)`, `lng (double)`, `location_updated_at (timestamptz)`.
- `friendships` — `user_id`, `friend_id`, `created_at`, PK مركب.
- `messages` — `id`, `sender_id`, `receiver_id`, `text`, `type ('text'|'image'|'audio')`, `media_url`, `audio_duration`, `delivered (bool)`, `read (bool)`, `created_at`.
- `typing_status` — `user_id`, `chat_with`, `is_typing`, `updated_at`.
- `blocks` — `blocker_id`, `blocked_id`, `created_at`, PK مركب.

كل جدول: `GRANT` كامل + RLS. سياسات:
- `profiles`: الجميع (authenticated) يقرأ الاسم والصورة والحالة؛ الموقع يُقرأ فقط لمن `hide_location=false`؛ التعديل للمالك فقط.
- `messages`: يقرأ ويكتب من هو `sender` أو `receiver`.
- `blocks`, `friendships`, `typing_status`: خاصة بالمستخدم.

Realtime على `messages` و`typing_status` و`profiles`.

Storage buckets:
- `chat-media` (public read) — للصور والفيديو.
- `voice-messages` (public read) — للرسائل الصوتية.
- `avatars` (public read).

Function: `nearby_users(radius_km)` تُرجع من `hide_location=false` و`is_online=true` ضمن النطاق باستخدام Haversine.

## المصادقة

Phone OTP عبر Supabase Auth. صفحة `/auth` جديدة (استبدال الاعتماد على localStorage phone). عند أول دخول: إنشاء صف في `profiles` بالهاتف والاسم.

**ملاحظة**: تفعيل مزود Phone في Cloud يحتاج SMS provider (Twilio). للمعاينة سنبدأ بـ Email/Password + Phone كحقل ملف شخصي؛ ونضيف OTP فعلياً حين تُتاح بيانات Twilio. سأوضح ذلك للمستخدم بعد التنفيذ.

## الشات اللحظي

- استبدال `chat-storage.ts` بـ hooks تقرأ/تكتب من Supabase.
- Realtime subscription على `messages` مع فلترة `receiver_id=auth.uid()`.
- علامات: `delivered` تُحدَّث عند وصول الرسالة، `read` عند فتح المحادثة، `typing_status` upsert أثناء الكتابة (debounced 2s).
- شارة "متصل الآن" من `profiles.is_online` + `last_seen`. Presence عبر heartbeat كل 30s.

## الرسائل الصوتية (تصليح)

- Long-press على زر المايك ➜ `MediaRecorder` يبدأ.
- Release ➜ يوقف، يرفع إلى `voice-messages/{userId}/{uuid}.webm`، ثم `insert` في `messages` بنوع `audio` مع `media_url` و`audio_duration`.
- عند فشل الرفع: toast "فشل الإرسال، حاول مرة أخرى".
- مشغل مخصص في فقاعة الرسالة (play/pause + شريط تقدم + مدة).

## رفع الصور

`chat-media/{userId}/{uuid}.jpg` ثم `insert` messages بنوع `image`.

## من حولك (GPS)

- `navigator.geolocation.getCurrentPosition` → `upsert` إلى `profiles(lat,lng,location_updated_at)`.
- استعلام `nearby_users(5)` مع استبعاد المحظورين.
- Toggle "إخفاء موقعي" يحدّث `hide_location`.
- ضغطة على أي شخص ➜ `/chat/{id}` مباشرة.

## الحظر / إلغاء الحظر

- في شاشة الشات: زر "حظر المستخدم" في قائمة الـ 3 نقاط ➜ `insert` في `blocks`.
- المحظورون لا تظهر رسائلهم ولا في "من حولك".
- في `/settings` قسم جديد "المحظورين" يقرأ من `blocks` مع زر "إلغاء الحظر" (`delete`).

## الملفات المتأثرة

جديد: `src/routes/auth.tsx`, `src/lib/supabase-chat.ts`, `src/lib/location.ts`, `src/lib/blocks.ts`, `src/components/VoiceRecorder.tsx`, `src/components/AudioPlayer.tsx`, migration.

تعديل: `src/routes/index.tsx`, `chat.$id.tsx`, `discover.tsx`, `settings.tsx`, `profile.tsx`, `__root.tsx` (presence heartbeat + auth guard).

RTL موجود أصلاً.

## قيود مهمة

- **حجم العمل كبير**؛ قد أحتاج جولة أو جولتين لإكماله كاملاً بدون كسر البناء.
- **Phone OTP الحقيقي** يحتاج Twilio (سأشغّل الخطوة بديلاً بـ Email أو Phone مبسّط، وأخبرك كيف نُفعّل OTP فعلياً).
- سأحافظ على الأيقونات و PWA والتصميم الحالي كما هو.
