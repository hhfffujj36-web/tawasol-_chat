
-- Read: any authenticated user can read files in these buckets
CREATE POLICY "read_chat_media" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id IN ('chat-media','voice-messages','avatars'));

-- Insert: only into own folder (first path segment = auth uid)
CREATE POLICY "upload_own_chat_media" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('chat-media','voice-messages','avatars')
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "delete_own_chat_media" ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id IN ('chat-media','voice-messages','avatars')
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
